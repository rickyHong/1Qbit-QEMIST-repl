# Microsoft.Quantum.Chemistry #

C# and Q# sources used to implement the Microsoft Quantum Chemistry library. All files in this library are intended to eventually be open-sourced under the MIT license, like the other components of github.com/microsoft/quantum.

## Structure of the Library

- **[DataModel](DataModel/)**:
    This is a C# library that handles loading a chemistry Hamiltonian from file into a standard format. This library also handles classical preprocessing & optimization of the standard format to a format specialized for consumption by various Q# simulation algorithms.

- **[Chemistry](Chemistry/)**:
    This Q# library contains methods specific to simulating chemistry Hamiltonians that are output by the DataModel library.

- **[CanonAdditions](CanonAdditions/)**:
    This Q# library contains methods that will be eventually merged with the Microsoft.Quantum.Canon library.