# Microsoft.Quantum.Chemistry #

C# and Q# sources used to implement the Microsoft Quantum Chemistry library. All files in this library are intended to eventually be open-sourced under an MSR license that permits non-commercial use, like the other components of github.com/microsoft/quantum-nc.

## Structure of the Library

- **JordanWignerOptimizedEvolutionSet.qs**:
    Optimized reordering of PQRS terms in Jordan Wigner encoding to achieve cancellation of circuit that implement neighboring terms. 
    
- **LibrariesNC.csproj**:
    C# project file
    